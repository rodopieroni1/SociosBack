package com.Socios.socios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SociosApplicationTests {

	@Test
	void contextLoads() {
	}

}
